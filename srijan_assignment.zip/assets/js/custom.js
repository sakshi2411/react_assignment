function Validate() {
  // console.log('aaaa')
  $('form')
    .each(function () {
      var validator = $(this).validate({
        ignore: 'input[type=hidden], .select2-input',
        highlight: function (element) {
          $(element)
            .closest('.form-group')
            .addClass('has-error')
        },
        unhighlight: function (element) {
          $(element)
            .closest('.form-group')
            .removeClass('has-error')
          $(element)
            .closest('.form-group')
            .find('.help-block')
            .hide()
        },
        errorElement: 'span',
        errorClass: 'help-block',
        errorPlacement: function (error, element) {
          if (element.parents('div').hasClass('checker') || element.parents('div').hasClass('choice') || element.parent().hasClass('bootstrap-switch-container')) {
            if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
              error.appendTo(element.parent().parent().parent().parent())
            } else {
              error.appendTo(element.parent().parent().parent().parent().parent())
            }
          } else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
            error.appendTo(element.parent().parent().parent())
          } else if (element.parents('div').hasClass('has-feedback')) {
            error.appendTo(element.parent())
          } else if (element.parents('div').hasClass('multi-select-full')) {
            error.insertAfter(element.parent())
          } else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
            error.insertAfter(element.parent().parent())
          } else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
            error.appendTo(element.parent().parent())
          } else {
            error.insertAfter(element)
          }
        },
        successClass: 'validation-valid-label',
        validClass: 'validation-valid-label',
        success: function (element) {
          $(element)
            .closest('.form-group')
            .removeClass('has-error')
          $(element)
            .closest('.form-group')
            .find('.help-block')
            .hide()
        }
      })
    })
}

function Validator() {
  // console.log('bbbb')
  $.validator.prototype.elements = function () {
    var validator = this,
      rulesCache = {}
    return $([])
      .add(this.currentForm.elements)
      .filter(':input')
      .not(':submit, :reset, :image, [disabled]')
      .not(this.settings.ignore)
      .filter(function () {
        var elementIdentification = this.id || this.name
        !elementIdentification && validator.settings.debug && window.console && console.error('%o has no id nor name assigned', this)
        if (elementIdentification in rulesCache || !validator.objectLength($(this).rules()))
          return false
        rulesCache[elementIdentification] = true
        return true
      })
  }

  // ---------------------------------------   Rule Class
  // ---------------------------------------------------//

  $
    .validator
    .addClassRules('text', {
      required: true,
      alphaonly: true
    })

  $
    .validator
    .addClassRules('textButNotRequired', { alphaonly: true })

  $
    .validator
    .addClassRules('textButOnlyRequired', { required: true })

  $
    .validator
    .addClassRules('number', {
      required: true,
      numeric: true
    })

  $
    .validator
    .addClassRules('no_0_number', {
      required: true,
      nozeronumber: true
    })

  $
    .validator
    .addClassRules('number_with_separator', { numericwithseparater: 'optional' })

  $
    .validator
    .addClassRules('decimal_Numeric', { decimalNumeric: 'optional' })

  $
    .validator
    .addClassRules('email', {
      required: true,
      email: true
    })

  $
    .validator
    .addClassRules('alphanum', {
      required: true,
      alphanumeric: true
    })

  $
    .validator
    .addClassRules('optional', { alphanumeric: 'optional' })

  $
    .validator
    .addClassRules('accept_all', {
      required: true,
      alphanumeric_special: true
    })

  $
    .validator
    .addClassRules('new_password', {
      required: true,
      password1: true
    })

  $
    .validator
    .addClassRules('confirm_password', {
      required: true,
      equalTo: '#txtNewPassword'
    })

  $
    .validator
    .addClassRules('phone', {
      required: true,
      phone_number: true
    })

  $
    .validator
    .addClassRules('zip', {
      required: true,
      zipcode: true
    })

  $
    .validator
    .addClassRules('ssn', {
      required: true,
      ssn: true
    })

  $
    .validator
    .addClassRules('select-validation', {
      selectValidation: true
    })


  // ---------------------------------------   Rule Methods
  // ---------------------------------------------------// ----- For IPV4 & IPV6

  $.validator.addMethod("selectValidation", function (value, element, arg) {
    console.log(value, ':', element, ':', arg)
    return value != 0;
  }, "Please Select an Item.");


  /* SelectName
   // configure your validation
   $("form").validate({
    rules: {
     SelectName: { valueNotEquals: "default" }
    },
    messages: {
     SelectName: { valueNotEquals: "Please select an item!" }
    }  
   }); 
   */


  $
    .validator
    .addMethod('ipv4_ipv6', function (value, element, param) {
      var ipv4_6 = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$|^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/
      if (param === 'optional') {
        return this.optional(element) || value.match(ipv4_6)
      } else {
        return value.match(ipv4_6)
      }
    }, 'Please Enter Proper IP Address')

  // ----- For IPV4
  $
    .validator
    .addMethod('ipv4', function (value, element, param) {
      var ipv4 = /^(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[0-9]{2}|[0-9])(\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[0-9]{2}|[0-9])){3}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(ipv4)
      } else {
        return value.match(ipv4)
      }
    }, 'Please Enter Correct Format of IPV4 Address')

  // ----- For Domain name
  $
    .validator
    .addMethod('domainname', function (value, element, param) {
      var qualified_domain = /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(qualified_domain)
      } else {
        return value.match(qualified_domain)
      }
    }, 'Please Enter Valid Domain Name')

  // ----- For Domain name / IP Fields
  $
    .validator
    .addMethod('domainname_ip', function (value, element, param) {
      var ip = /^(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[0-9]{2}|[0-9])(\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[0-9]{2}|[0-9])){3}$/
      var simple_domain = /^[a-zA-Z0-9]+[a-zA-Z0-9-]*[a-zA-Z0-9]+$/
      var qualified_domain = /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/
      if (param === 'optional') {
        return (this.optional(element) || value.match(ip) || value.match(simple_domain) || value.match(qualified_domain)) && value.length <= 64
      } else {
        return (value.match(ip) || value.match(simple_domain) || value.match(qualified_domain)) && value.length <= 64
      }
    }, 'Please Enter Correct Format of Either Domain Name or IP')

  // ----- For Multiple IP's and Domain name's.
  $
    .validator
    .addMethod('domainnames_ips', function (value, element, param) {
      var ips = /^\*$|^(?:\d|1?\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d|1?\d\d|2[0-4]\d|25[0-5])){3}(?:\s*,\s*(?:\d|1?\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d|1?\d\d|2[0-4]\d|25[0-5])){3})*$/
      var simple_domains = /^([a-zA-Z0-9]+[a-zA-Z0-9-]*[a-zA-Z0-9]|,(?!,|$)){1,}$/
      var qualified_domains = /^(([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}|,(?!,|$)){1,}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(ips) || value.match(simple_domains) || value.match(qualified_domains)
      } else {
        return value.match(ips) || value.match(simple_domains) || value.match(qualified_domains)
      }
    }, 'Please Enter Correct Format of Either Domain Names or IPs')

  // ----- For Simple & Qualified hostname
  $
    .validator
    .addMethod('hostname', function (value, element, param) {
      var simple_domain = /^[a-zA-Z0-9]+[a-zA-Z0-9-]*[a-zA-Z0-9]+$/
      var qualified_domain = /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/
      if (param === 'optional') {
        return (this.optional(element) || value.match(simple_domain) || value.match(qualified_domain)) && value.length() <= 64
      } else {
        return (value.match(simple_domain) || value.match(qualified_domain)) && value.length <= 32
      }
    }, 'Please Enter Proper Hostname')

  // ----- For Alphanumeric Only.
  $
    .validator
    .addMethod('alphanumeric', function (value, element, param) {
      var alphanum = /^[a-zA-Z0-9]*$/
      if (param === 'optional') {
        return (this.optional(element) || value.match(alphanum)) && value.length() <= 64
      } else {
        return (value.match(alphanum) && value.length <= 64)
      }
    }, 'Only Alphabets and Numbers are allowed')

  // ----- For Alphanumeric & Special Characters
  $
    .validator
    .addMethod('alphanumeric_special', function (value, element, param) {
      var alphanum_special = /^[ a-zA-Z0-9!"@#$%&()*\+,.':\/;\[\\\]\^_`-]+$/
      if (param === 'optional') {
        return this.optional(element) || value.match(alphanum_special)
      } else {
        return value.match(alphanum_special)
      }
    }, 'Only Alphabets,Numbers & Special Characters are allowed')

  // ----- For Alphabets only with spaces
  $
    .validator
    .addMethod('alphaonly', function (value, element, param) {
      var alpha = /^[a-zA-Z ]*$/
      if (param === 'optional') {
        return this.optional(element) || value.match(alpha)
      } else {
        return value.match(alpha)
      }
    }, 'Please Enter Alphabets Only')

  // ----- For Number only with spaces
  $
    .validator
    .addMethod('numeric', function (value, element, param) {
      var number = /^[0-9]+$/
      if (param === 'optional') {
        return this.optional(element) || value.match(number)
      } else {
        return value.match(number)
      }
    }, 'Please Enter Numbers Only')

  // ----- For Number only with spaces greater than zero
  $
    .validator
    .addMethod('nozeronumber', function (value, element, param) {
      var number = /^(?=.*[1-9])[0-9,]+$/
      if (param === 'optional') {
        return this.optional(element) || value.match(number)
      } else {
        return value.match(number)
      }
    }, 'Please Enter Numbers Greater Than Zero')

  // ----- For Number only with separater
  $
    .validator
    .addMethod('numericwithseparater', function (value, element, param) {
      var number = /^[0-9,]+$/
      if (param === 'optional') {
        return this.optional(element) || value.match(number)
      } else {
        if (typeof (value) === 'boolean')
          return '0'

        return value.match(number)
      }
    }, 'Please Enter Positive Numbers Only')

  // ----- For decimal number
  $
    .validator
    .addMethod('decimalNumeric', function (value, element, param) {
      var number = /^\d+(\.\d{1,3})?$/
      if (param === 'optional') {
        return this.optional(element) || value.match(number)
      } else {
        if (typeof (value) === 'boolean')
          return '0'

        return value.match(number)
      }
    }, 'Please Enter Positive Numbers Only')

  // ----- For Port only with 5 maxlength
  $
    .validator
    .addMethod('port', function (value, element, param) {
      var port = /^([0-9]){0,5}$/
      var val = parseInt(value, 10)
      if (param === 'optional') {
        return (this.optional(element) || value.match(port)) && (val <= port_range && val > 0)
      } else {
        return value.match(port) && (val <= port_range && val > 0)
      }
    }, 'Please Enter Proper Port Number')

  // ----- For Phone Number ('+' (is also optional) followed by 15 digits, spaces
  // are optional and minimum 10 digits - maximum 15 digits.)
  $
    .validator
    .addMethod('phone_number', function (value, element, param) {
      var phonenumber = /^\+?([0-9][ ]*){10,15}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(phonenumber)
      } else {
        return value.match(phonenumber)
      }
    }, 'Please Enter Valid Phone Number')

  // ----- For Phone Number ('+' (is also optional) followed by 15 digits spaces
  // optional and minimum 10 digits - maximum 15 digits.)
  $
    .validator
    .addMethod('fax', function (value, element, param) {
      var faxnumber = /^\+?([0-9][ ]*){10,15}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(faxnumber)
      } else {
        return value.match(faxnumber)
      }
    }, 'Please Enter Valid Fax Number')

  // ----- For ZipCode (Alphabet with Number maximum 20 digits No spaces)
  $
    .validator
    .addMethod('zipcode', function (value, element, param) {
      var zip = /^([a-zA-Z0-9]){5,20}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(zip)
      } else {
        return value.match(zip)
      }
    }, 'Please Enter Valid Zipcode')

  // ----- For Email (Case Sensitive accept only small Letter.)
  $
    .validator
    .addMethod('email', function (value, element, param) {
      var emailid = /^[A-Za-z0-9]+([._\+\-]?[A-Za-z0-9])*@[A-Za-z0-9]+([-]?[A-Za-z0-9])*([.][A-Za-z]{1,})+$/
      if (param === 'optional') {
        return this.optional(element) || value.match(emailid)
      } else {
        return value.match(emailid)
      }
    }, 'Please Enter Valid Email Address')

  // ----- For Password1 (Passwords must be 8-32 characters in length, and contain
  // at least 1 uppercase, 1 lowercase letter, 1 digit, and 1 non-alphanumeric
  // character)
  $
    .validator
    .addMethod('password1', function (value, element, param) {
      var pass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[=~!{|<>?}"@#$%&()*\+,.':\/;\[\\\]\^_`-])[A-Za-z\d=~!{|<>?}"@#$%&()*\+,.':\/;\[\\\]\^_`-]{8,32}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(pass)
      } else {
        return value.match(pass)
      }
    }, 'Please Enter Correct Password Format')

  // ----- For Password2 (The password is limited to 31 alphanumerical characters
  // plus the following characters: +, -, _, *, @)
  $
    .validator
    .addMethod('password2', function (value, element, param) {
      var pass = /^[a-zA-Z0-9@*+_-]{0,31}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(pass)
      } else {
        return value.match(pass)
      }
    }, 'Please Enter Correct Password Format')

  // ----- For validating SSN
  $
    .validator
    .addMethod('ssn', function (value, element, param) {
      // var number =
      // /^(?!219-09-9999|078-05-1120)(?!666|000|9\d{2})\d{3}-(?!00)\d{2}-(?!0{4})\d{4}
      // $/
      var number = /^\d{3}-\d{2}-\d{4}$/
      if (param === 'optional') {
        return this.optional(element) || value.match(number)
      } else {
        return value.match(number)
      }
    }, 'Invalid SSN')
}

function Validation() {
  Validate()
  Validator()
}

function getCookie(cname) {
  var name = cname + '='
  var decodedCookie = decodeURIComponent(document.cookie)
  var ca = decodedCookie.split(';')
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i]
    while (c.charAt(0) == ' ') {
      c = c.substring(1)
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length)
    }
  }
  return ''
}

function delete_cookie(name) {
  document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;'
}

function notifyMsg(msgType, message) {
  // console.log("Notify")
  noty({
    width: 4000,
    text: message,
    type: 'ui-pnotify-shadow alert-' + msgType,
    dismissQueue: true,
    timeout: 2000,
    layout: 'center',
    killer: true,
    animation: {
      open: {
        height: 'toggle'
      },
      close: {
        height: 'toggle'
      },
      easing: 'swing',
      speed: 0
    }
  })
}

function blockMyUI(message) {
  $('.pageContent').block({
    message: '<span class="text-semibold"><i class="icon-fontello-spinner2 position-left"></i>' +
    '&nbsp;' + message + '</span>',
    overlayCSS: {
      backgroundColor: '#1b2024',
      opacity: 0.5,
      cursor: 'wait'
    },
    css: {
      border: 0,
      padding: '10px 15px',
      color: '#fff',
      width: 'auto',
      '-webkit-border-radius': 2,
      '-moz-border-radius': 2,
      backgroundColor: '#333',
      top: '45%',
      left: '45%'
    }
  })
}

function unblockMyUI() {
  $('.pageContent').unblock()
  // $.unblockUI()
}

// useful in case like add Data or Success of some activity
function responseCheckWithNotify(res) {
  unblockMyUI()
  if (res.data.code == 200) {
    notifyMsg('success', res.data.message)
  } else {
    notifyMsg('danger', res.data.message)
  }
}

// useful in case like just Fetch & display Data
function responseCheckWithoutNotify(res) {
  unblockMyUI()
  if (res.data.code == 200) { } else {
    notifyMsg('danger', res.data.message)
  }
}

function isEmpty(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key))
      return false
  }
  return true
}

function roleAccessCheck(url, view, add, del, update, sentuser, sendgroup, sendall) {
  let setaccess = []
  let Logdata = JSON.parse(localStorage.getItem('Logindata'))
  let Logres = Logdata.access[0].funcs

  let path = $.grep(Logres, function (e) {
    return url.indexOf(e.link) > -1
    // return e.link == url
  })

  let subpathaccess = path[0].funcs
  console.log(subpathaccess, 'subpathaccess')
  let roleaccesscheck = subpathaccess.map(function (k, v) {
    let accesschecker = k.title.trim()

    console.log(accesschecker, 'accesschecker')

    if (accesschecker == view) {
      setaccess.push('view')
    } else if (accesschecker == add) {
      setaccess.push('add')
    } else if (accesschecker == del) {
      setaccess.push('del')
    } else if (accesschecker == update) {
      setaccess.push('update')
    } else if (accesschecker == sentuser) {
      setaccess.push('sentuser')
    } else if (accesschecker == sendgroup) {
      setaccess.push('sendgroup')
    } else if (accesschecker == sendall) {
      setaccess.push('sendall')
    }
  })
  console.log(setaccess, 'setaccess')
  return setaccess
}

// To delete all the Cookie and the localStorage data
function deleteAllCookieAndStorageContent() {
  delete_cookie('connect.sid')
  localStorage.clear()
}

// Form Validation
function formValidateCheck(formName) {
  var formValidationState = $('#' + formName)
    .data('validator')
    .form()
  return formValidationState
}

function getFileNameFromFullPath(fullPath) {
  var filename,
    fullfilename = ''
  if (fullPath) {
    var startIndex = (fullPath.indexOf('\\') >= 0
      ? fullPath.lastIndexOf('\\')
      : fullPath.lastIndexOf('/'))
    filename = fullPath.substring(startIndex)
    if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
      filename = filename.substring(1)
    }
    fullfilename = filename
  }
  return fullfilename
}

var technicianLocation = [
  {
    'name': 'Technician 1',
    'id': '1',
    'time_coordinates': [
      '1pm', '2pm', '3pm', '4pm', '5pm'
    ],
    'coordinates': [
      [
        -12.006846, -77.131956
      ],
      [
        -12.030344, -77.135447
      ],
      [
        -12.029139, -77.122921
      ],
      [
        -12.054041, -77.124153
      ],
      [-12.063479, -77.143455]
    ],
    'color': '#3498db'
  }, {
    'name': 'Technician 2',
    'id': '2',
    'time': [
      '1pm', '2pm', '3pm', '4pm', '5pm'
    ],
    'coordinates': [
      [
        -11.984580, -77.049336
      ],
      [
        -11.981135, -77.025388
      ],
      [
        -12.015813, -77.024449
      ],
      [
        -12.014435, -76.996979
      ],
      [-11.999049, -76.973970]
    ],
    'color': '#e74c3c'
  }, {
    'name': 'Technician 3',
    'id': '3',
    'time': [
      '1pm', '2pm', '3pm', '4pm', '5pm'
    ],
    'coordinates': [
      [
        -12.073447, -77.106154
      ],
      [
        -12.073447, -77.092771
      ],
      [
        -12.087681, -77.074693
      ],
      [
        -12.079416, -77.048162
      ],
      [-12.089518, -77.044640]
    ],
    'color': '#2ecc71'
  }, {
    'name': 'Technician 4',
    'id': '4',
    'time': [
      '1pm', '2pm', '3pm', '4pm', '5pm'
    ],
    'coordinates': [
      [
        -12.047961, -77.014118
      ],
      [
        -12.062197, -76.994162
      ],
      [
        -12.040154, -76.977727
      ],
      [
        -12.060130, -76.963874
      ],
      [-12.060130, -76.936874]
    ],
    'color': '#8e44ad'
  }
]

function createZonePolygon(latVal, lngVal, pathVal, pathColor) {
  console.log('Create Zone Was Called')
  console.log(latVal)
  console.log(lngVal)
  console.log(pathVal)
  console.log(pathColor)

  var map = new GMaps({ div: '#geojson', lat: latVal, lng: lngVal, scrollwheel: true, zoom: 6 })

  var polygon3 = map.drawPolygon({
    paths: pathVal,
    useGeoJSON: true,
    strokeColor: pathColor,
    strokeOpacity: 1,
    strokeWeight: 3,
    fillColor: pathColor,
    fillOpacity: 0.6
  })
}

function setMenuPath(path) {
  var count = $('ul.sidebar-nav').find('li').length
  for (i = 0; i < count; i++) {
    var data = $('ul.sidebar-nav').find('li > a').eq(i).attr('href')
    if (data == path) {
      $('ul.sidebar-nav').find('li').removeClass('active').eq(i).addClass('active')
      return
    }
  }
}

function dualbox() {
  $('.permissions-input').bootstrapDualListbox({
    nonSelectedListLabel: 'All Roles',
    selectedListLabel: 'Selected Roles',
    preserveSelectionOnMove: 'moved',
    moveOnSelect: false,
    showFilterInputs: false
  })
}

var serviceRequestMarkers = {
  'Day1': [
    {
      'name': 'SRMarker1',
      'lat': '-12.030637',
      'lng': '-77.113510'
    },
    {
      'name': 'SRMarker2',
      'lat': '-11.984580',
      'lng': '-77.049336'
    },
    {
      'name': 'SRMarker3',
      'lat': '-12.073447',
      'lng': '-77.106154'
    },
    {
      'name': 'SRMarker4',
      'lat': '-12.087681',
      'lng': '-77.074693'
    }
  ],
  'Day2': [
    {
      'name': 'SRMarker1',
      'lat': '-12.060899',
      'lng': '-77.134103'
    },
    {
      'name': 'SRMarker2',
      'lat': '-12.002732',
      'lng': '-77.077770'
    },
    {
      'name': 'SRMarker3',
      'lat': '-11.998840',
      'lng': '-77.130962'
    },
    {
      'name': 'SRMarker4',
      'lat': '-12.051358',
      'lng': '-77.050888'
    }
  ]
}

var technicianMarkers = {
  'Day1': [
    {
      'name': 'TMarker1',
      'lat': '-12.029139',
      'lng': '-77.122921'
    },
    {
      'name': 'TMarker2',
      'lat': '-11.981135',
      'lng': '-77.025388'
    },
    {
      'name': 'TMarker3',
      'lat': '-12.060130',
      'lng': '-76.963874'
    },
    {
      'name': 'TMarker4',
      'lat': '-11.999049',
      'lng': '-76.973970'
    }
  ],
  'Day2': [
    {
      'name': 'TMarker1',
      'lat': '-12.031982',
      'lng': '-77.107918'
    },
    {
      'name': 'TMarker2',
      'lat': '-12.043762',
      'lng': '-77.096360'
    },
    {
      'name': 'TMarker3',
      'lat': '-12.056731',
      'lng': '-77.082004'
    },
    {
      'name': 'TMarker4',
      'lat': '-12.071604',
      'lng': '-77.085897'
    }
  ]
}
function tagInit(user_id, user_name, action) {
  console.log(action, 'action')
  $('.tags-input').tagsinput({
    itemValue: 'id',
    itemText: 'text'
  })
  if (action == true) {
    $('.tags-input').tagsinput('add', { id: user_id, text: user_name })
  } else if (action == false) {
    $('.tags-input').tagsinput('remove', { id: user_id, text: user_name })
  }
}

function removeAll(tagsinput) {
  $('.' + tagsinput).tagsinput('removeAll')
}
function removeEvent(callback, tableid, myId) {
  $('.tag').on('itemRemoved', function (event) {
    let e = $('#' + tableid).find(':checkbox[value=' + event.item.id + ']')
    e.prop('checked', false)
    $(e.parent('span')[0]).removeClass('checked')
    callback(event.item.id)
    console.log(myId)
    if (myId.length == 0) {
      $('.mytagInputLabel').hide()
      $('.bootstrap-tagsinput').hide()
    } else {
      $('.mytagInputLabel').show()
      $('.bootstrap-tagsinput').show()
    }
  })
}

function initialisefilter() {
  $('.showfilter').click(function () {
    $('.filterinput').animate({ left: 0, opacity: 'show' }, 500)
  })

  $('.cancelinput').click(function () {
    $('.filterinput').animate({ left: '-81%', opacity: 'hide' }, 500)
  })

  $('.daterange-single').daterangepicker({
    singleDatePicker: true,

  })

  $('.daterange-singleforincidence').daterangepicker({
    singleDatePicker: true,
    minDate: new Date()
  })
  $('.selectfilter').select2({
    minimumResultsForSearch: Infinity
  })
}

/*function Localisation(){
     var lang = localStorage.getItem('Language')
     var selectedlanguage
    if (lang == "" || lang == null || lang == undefined) {
        localvariable = '../../Locale/English/'
        //  $('#slLanguage').val("English")
        selectedlanguage = 'English'
    } else {
        localvariable = '../../Locale/' + lang + '/'
        //  $('#slLanguage').val(lang)
        selectedlanguage = lang
    }

   
}*/

function setLocalisation(lang) {
  localStorage.setItem('Language', lang)
}

function RadioCheckbox() {
  $('.styled, .multiselect-container input').uniform({
    radioClass: 'choice'
  })
}

function FileStyled() {
  $('.file-styled-primary').uniform({
    fileButtonClass: 'action btn bg-blue'
  })
}

function RadiomyCheckbox() {
  $('.nstyled').uniform({
    radioClass: 'choice'
  })
}
function tagsInputToggle(count) {
  if (count == 0) {
    $('.mytagInputLabel').hide()
    $('.bootstrap-tagsinput').hide()
  } else {
    $('.mytagInputLabel').show()
    $('.bootstrap-tagsinput').show()
  }
}

function initializeSwitcheryRadioBox() {
  // Initialize multiple switches
  /* if (Array.prototype.forEach) {
      console.log(1)
      var elems = Array.prototype.slice.call(document.querySelectorAll('.switchery'))
      console.log(3, elems)
      elems.forEach(function(html) {
          var switchery = new Switchery(html)
      })
  }
  else {
      console.log(2)
      var elems = document.querySelectorAll('.switchery')
      console.log(elems)
      for (var i = 0; i < elems.length; i++) {
          var switchery = new Switchery(elems[i])
      }
  } */

  // var primary = document.querySelector('.switchery-primary')
  var elems = document.querySelectorAll('.switchery-primary')

  console.log(elems, 'Switchery Elements')
  for (var i = 0; i < elems.length; i++) {
    var switchery = new Switchery(elems[i], { color: '#2196F3' })
  }

  /* 
  // Colored switches
  
  var danger = document.querySelector('.switchery-danger')
  var switchery = new Switchery(danger, { color: '#EF5350' })
  
  var warning = document.querySelector('.switchery-warning')
  var switchery = new Switchery(warning, { color: '#FF7043' })
  
  var info = document.querySelector('.switchery-info')
  var switchery = new Switchery(info, { color: '#00BCD4'}); 
  */
}

function initializeSelect2() {
  $('.select').select2({
    minimumResultsForSearch: Infinity
  })
}

function multiAdd() {
  $(".add-more").click(function () {
    var html = $(".entitycopy").html();
    $(".after-add-more").after(html);
  });

  $("body").on("click", ".removeClick", function () {
    $(this).parents(".control-group").remove();
  });
}

function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}