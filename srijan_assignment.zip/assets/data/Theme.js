module.exports = {
  'Theme': [
    {
      'theme_id': 1,
      'theme_name': 'PRA',
      'company_name': 'PRA',
      'company_logo': 'PRA.png',
      'primary_color': '#FF82AB',
      'secondary_color': '#FFB6C1',
      'status': false
    },
    {
      'thDme_id': 2,
      'theme_name': 'PHDC',
      'company_name': 'PHDC',
      'company_logo': 'PHDC',
      'primary_color': '#BA55D3',
      'secondary_color': '#9B30FF',
      'status': false
    },
    {
      'theme_id': 3,
      'theme_name': 'OnSiteGo',
      'company_name': 'OnSiteGo',
      'company_logo': 'OnSiteGo.png',
      'primary_color': '#4876FF',
      'secondary_color': '#63B8FF',
      'status': false
    },
    {
      'theme_id': 4,
      'theme_name': 'Barometer',
      'company_name': 'Barometer',
      'company_logo': 'Barometer.jpg',
      'primary_color': '#00F5FF',
      'secondary_color': '#5F9EA0',
      'status': false
    },
    {
      'theme_id': 5,
      'theme_name': 'NMHC',
      'company_name': 'New Mexico Heealth Connection',
      'company_logo': 'NMHC.png',
      'primary_color': '#00CD66',
      'secondary_color': '#2E8B57',
      'status': false
    },
    {
      'theme_id': 6,
      'theme_name': 'GBG',
      'company_name': 'Global Benefit Group',
      'company_logo': 'GBG.png',
      'primary_color': '#FFD700',
      'secondary_color': '#EEB422',
      'status': false
    },
    {
      'theme_id': 7,
      'theme_name': 'Mobilize',
      'company_name': 'Mobilize',
      'company_logo': 'Mobilize.png',
      'primary_color': '#FFD700',
      'secondary_color': '#EEB422',
      'status': true
    },
    {
      'theme_id': 8,
      'theme_name': 'Limitless',
      'company_name': 'Limitless',
      'company_logo': 'Limitless.png',
      'primary_color': '#FFD700',
      'secondary_color': '#EEB422',
      'status': false
    }
]}
