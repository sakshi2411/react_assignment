import React from 'react'
import { Route, IndexRoute, Redirect, Link, browserHistory, hashHistory, withRouter } from 'react-router'

import Home from './components/Home'


class App extends React.Component {
  render() {
    return (
      <div>
        <Home/>
      </div>
    )
  }
}


const routesApp = (
  <Route component={App}>
    <Route path={'/'} component={Home} />
  </Route>
)



const combinedRoutes = (
  <Route>
    <Route>
      {routesApp}
    </Route>
  </Route>
)

export default (
  <Route>
    {combinedRoutes}
  </Route>
)
