import { 
	PRODUCTS_LIST 
} from './action'

let INITIAL_STATE = {
	products :[]
}
function reducer (state = INITIAL_STATE , action) {
  switch (action.type) {
	case PRODUCTS_LIST:
		return {...state,products : action.payload ? action.payload : [] }
	
    default:
     	return state
  }
}

export default reducer
