import axios from 'axios'


let productList=[
	{
		product: "Product1",
		value: "#f00"
	},
	{
		product: "Product2",
		value: "#0f0"
	},
	{
		product: "Product3",
		value: "#00f"
	},
	{
		product: "Product4",
		value: "#0ff"
	},
	{
		product: "Product5",
		value: "#f0f"
	},
	{
		product: "Product6",
		value: "#ff0"
	},
	{
		product: "Product7",
		value: "#000"
	}
]
export const PRODUCTS_LIST = 'PRODUCTS_LIST'
export function getProductList () {
  return {
    type: PRODUCTS_LIST,
    payload: productList
  }
}


