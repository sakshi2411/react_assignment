import React, { Component } from 'react';
import { reduxForm, initialize } from 'redux-form';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import _ from 'lodash';
import { getProductList } from './action';
import { Link, browserHistory, hashHistory, withRouter } from 'react-router';
class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    componentDidMount() {
        this.props.getProductList();
    }

    render() {
        let productList = this.props.homeReducer.products ? this.props.homeReducer.products : [];
        return (
            <div>
                <nav className="navbar navbar-inverse">
                    <div className="container-fluid">
                        <div className="navbar-header">
                            <button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                            <a className="navbar-brand" href="#">Products list</a>
                            {/* <ul className="nav navbar-nav navbar-right ">

                                <li><i className="hidden-xl hidden-lg hidden-md">ss</i></li>
                            </ul> */}
                        </div>
                        <div className="collapse navbar-collapse navbar-left" id="myNavbar">
                            <ul className="nav navbar-nav">
                                <li className="active"><a href="#">Home</a></li>
                                <li className="dropdown">
                                    <a className="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span className="caret"></span></a>
                                    <ul className="dropdown-menu">
                                        <li><a href="#">Page 1-1</a></li>
                                        <li><a href="#">Page 1-2</a></li>
                                        <li><a href="#">Page 1-3</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Page 2</a></li>
                                <li><a href="#">Page 3</a></li>
                            </ul>

                        </div>
                        {/* <div className="nav navbar-nav navbar-right " style={{ marginTop: "5px" }} >
                            <span> <a> <i className=" hidden-xs hidden-sm" style={{ color: "#fff" }}>hh</i></a></span>
                        </div> */}
                        <form className="navbar-form navbar-search navbar-right">
                            <a href="#" style={{color:"#fff"}}><i className="fa fa-search"></i></a>
                        </form>
                    </div>
                </nav>

                <div className="list-group">
                    {_.map((productList), function (v, k) {
                        return (
                            <a href="#" className="list-group-item" style={{ color: '#3e3e3e', fontWeight: "bold" }}>{v.product} <span style={{ color: "#e1e1e1" }} className="pull-right">></span></a>

                        )
                    })
                    }
                </div>

            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        homeReducer: state.homeReducer,
    }
}



export default connect(mapStateToProps, { getProductList })(Home)
