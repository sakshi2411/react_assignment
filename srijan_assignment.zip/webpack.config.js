module.exports = {
  entry: [
    './src/index.js'
  ],
  output: {
    path: __dirname,
    publicPath: '/',
    filename: 'bundle.js'
  },
  module: {
    loaders: [{
      exclude: /node_modules/,
      loaders: ['babel?presets[]=es2015&presets[]=react']
    },
    /* {
      test: /\.css$/,
      loader: 'style!css?importLoaders=1!postcss'
    } */
    { test: /\.css$/, loader: "style-loader!css-loader" },
/* 
    {
      test: /\.svg$/,
      loader: 'file',
      query: {
        name: 'static/media/[name].[hash:8].[ext]'
      }
    },
    {
      test: /\.ttf$/,
      loader: 'file',
      query: {
        name: 'static/media/[name].[hash:8].[ext]'
      }
    },
    {
      test: /\.woff$/,
      loader: 'file',
      query: {
        name: 'static/media/[name].[hash:8].[ext]'
      }
    },
    {
      test: /\.woff2$/,
      loader: 'file',
      query: {
        name: 'static/media/[name].[hash:8].[ext]'
      }
    },
    {
      test: /\.eot$/,
      loader: 'file',
      query: {
        name: 'static/media/[name].[hash:8].[ext]'
      }
    } */

    ]
  },
  resolve: {
    extensions: ['', '.js', '.jsx']
  },
  devServer: {
    port: 2001,
    contentBase: './',
    historyApiFallback: true,
  }
}
